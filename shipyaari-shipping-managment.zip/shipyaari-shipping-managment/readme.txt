=== Shipyaari Shipping Management === 
Contributors: piyushmca
Plugin Name: Shipyaari Shipping Management
Tags: Shipyaari Shipping Management, wordpress shipping,Woocommerce Shipyaari Shipping,Wordpress Shipyaari Shipping,Shipyaari Shipping Plugin,shipping Management,Shipyaari API 
Tested up to: 5.4
Requires at least: 3.8
Stable tag: 1.0
Requires PHP: 4.0 
WC requires at least: 2.1
WC tested up to: 4.0.1
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html
Simple and easy to use. You can easily add , update and delete shipping details.

== Description ==
**IMPORTANT: *Shipyaari Shipping Management* require wordpress 3.8 or higher.**

= Features =  

* Calculator Shipping Charges on checkout page

* Calculator Shipping Charges on Cart page

* Insert Shipping detail.

* Update Shipping detail.

* Delete Shipping detail.

* Woocommerce Shipyaari Shipping.


== Installation ==

**Shipyaari Shipping Management [Installation Guide]**

1. You can:
 * Upload the 'shipyaari-shippingm-management' folder to '/wp-content/plugins/' directory via FTP. 
 * Upload the full ZIP file via *Plugins -> Add New -> Upload* on your WordPress Administration Panel.
 * Search **Shipyaari Shipping Management** in the search engine available on *Plugins -> Add New* and press *Install Now* button.
2. Activate plugin through *Plugins* menu on WordPress Administration Panel.
3. Ready, now you can enjoy it, and if you like it and find it useful.

== Changelog ==
= 0.1 =
* Initial version.


== Thanks ==
* To all that use it.
* All that you help to improve it.
* All you made donations.
* All that you encourage us with your comments.

Thank you very much to all!