<?php 
// $search_service_url='http://avnbiz.co.in/test/AVNBIZ/webservice/SearchServiceV6.php';
// $create_consignment_url='http://avnbiz.co.in/test/AVNBIZ/webservice/test_upload_consignment.php';
// $track_consignment_url='http://avnbiz.co.in/test/AVNBIZ/webservice/ConsignmentPickupBook.php';

$search_service_url='https://seller.shipyaari.com/logistic/webservice/SearchServiceV6.php';
$create_consignment_url='https://seller.shipyaari.com/logistic/webservice/upload_consignment.php';
$track_consignment_url='https://seller.shipyaari.com/logistic/webservice/shipyaaritrack.php';
?>